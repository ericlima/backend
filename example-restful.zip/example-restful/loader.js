require('./server')
require('./config/database')